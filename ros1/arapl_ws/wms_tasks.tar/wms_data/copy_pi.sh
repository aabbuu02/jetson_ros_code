rm -rf /home/nvidia/Desktop/wms_instructions/wms_instructions/data/DBInstructions.csv
cp /home/nvidia/Desktop/wms_data/DBInstructions_pi.csv /home/nvidia/Desktop/wms_data/DBInstructions.csv
mv /home/nvidia/Desktop/wms_data/DBInstructions.csv /home/nvidia/Desktop/wms_instructions/wms_instructions/data/
rm -rf /home/nvidia/Desktop/wms_data/DBInstructions.csv
